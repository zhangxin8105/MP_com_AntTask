package ch.persi.ant.tasks;

import java.awt.Component;

public interface DialogComponent {
	
	public Component getComponent();
	
	public String getLabel();
	
	public boolean isReqiured();
	
	public String getValue();
	
	public String getName();
	

}
