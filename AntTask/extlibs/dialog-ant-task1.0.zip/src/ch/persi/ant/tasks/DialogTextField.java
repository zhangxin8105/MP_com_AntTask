/**
 * Project: 	Dialog Ant task
 * Licencse:	Apache 2.0
 * Copyright:	Bruno Persi, All rights reserved
 */

package ch.persi.ant.tasks;

import java.awt.Component;

import javax.swing.JTextField;

/**
 * this class defines a Textfield on the dialog, the following parameters are possible:
 * <ul>
 * size - the length of the Textfield
 * label - the label which is placed on the left of the Textfield
 * defaultValue - the default value, the value is shown in the Field
 * editable - marks it's the field editable or read only
 * required - required fields must be set by the user, else a BuildException is thrown
 * </ul>
 * 
 * @author Bruno Persi
 * @version 1.0
 * @since 1.0
 *
 */
public class DialogTextField implements DialogComponent{

	private JTextField field;
	private String lableCaption;
	private boolean required = Boolean.FALSE;
	
	public DialogTextField(){
		field = new JTextField();
	}
	
	public void setSize(int size){
		JTextField f = new JTextField(size);
		f.setText(field.getText());
		f.setEditable(field.isEditable());
		f.setName(field.getName());
		field = f;
	}
	
	public void setLabel(String caption){
		lableCaption = caption;
	}
	
	public void setDefaultvalue(String value){
		field.setText(value);
	}
	
	public void setEditable(boolean b){
		field.setEditable(b);
	}
	
	public Component getComponent(){
		return field;
	}
	
	public String getName(){
		return field.getName();
	}
	
	public String getLabel(){
		return lableCaption;
	}

	public void setRequired(boolean b) {
		required = b;
	}

	public boolean isReqiured() {
		return required;
	}

	public void setProperty(String s) {
		field.setName(s);
	}
	
	public String getValue(){
		return field.getText();
	}

}
