package ch.persi.ant.tasks;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;
import org.apache.tools.ant.taskdefs.Property;

import com.jgoodies.forms.builder.DefaultFormBuilder;
import com.jgoodies.forms.layout.FormLayout;

public class Dialog extends Task {

    private String dialogTitle;

    private List<DialogComponent> cmps;

    private boolean propertiesExists = Boolean.FALSE;

    private File properties;

    private JDialog frame;

    private List<Task> subTasks;
    
    

    public void addTask(Task task) {
        subTasks.add(task);
    }

    public void setDialogTitle(String s) {
        dialogTitle = s;
    }

    public void setPropertiespath(String path) {
        properties = new File(path + dialogTitle + ".properties");
        propertiesExists = properties.exists();
    }

    public void addTextField(DialogTextField field) {
        cmps.add(field);
    }

    public void addComboBox(DialogComboBox combobox) {
        cmps.add(combobox);
    }

    public void addRadioButtonGroup(DialogRadioButtonGroup radiobutton) {
        cmps.add(radiobutton);
    }

    public Dialog() {
        frame = new JDialog();
        cmps = new ArrayList<DialogComponent>(20);
        subTasks = new ArrayList<Task>(20);
    }

    public void execute() throws BuildException {
        //if the dialog saved with the values from last run, use this values and
        //dont show the dialog again.
        if (propertiesExists){
            setValuesToProject(Boolean.FALSE);
            return;
        }
        
        FormLayout layout = new FormLayout(
                "center:pref, 5dlu, center:pref, 3dlu", "");
        DefaultFormBuilder builder = new DefaultFormBuilder(layout);
        builder.setDefaultDialogBorder();
        int i = 0;
        for (Iterator<DialogComponent> iter = cmps.iterator(); iter.hasNext(); i++) {
            DialogComponent cmp = iter.next();
            if (i == 0) {
                builder.append(cmp.getLabel(), cmp.getComponent());
            } else if (cmp.getComponent().getClass().equals(JComboBox.class)) {
                builder.appendRow("15dlu");
                builder.append(cmp.getLabel(), cmp.getComponent(), 2);
            } else if (cmp.getComponent().getClass().equals(
                    RadioButtonGroupComponent.class)) {
                builder.appendRow("15dlu");
                RadioButtonGroupComponent c = (RadioButtonGroupComponent) cmp
                        .getComponent();
                DialogRadioButtonGroup dg = c.getGroup();

                if (dg.getRadioButtons().hasMoreElements()) {
                    builder.appendSeparator(cmp.getLabel());
                }
                for (Enumeration<AbstractButton> buttons = dg.getRadioButtons(); buttons
                        .hasMoreElements();) {
                    JRadioButton current = (JRadioButton) buttons.nextElement();
                    builder.append(current);
                }

            } else {
                builder.appendRow("15dlu");
                builder.append(cmp.getLabel(), cmp.getComponent());
            }
        }
        JPanel buttons = new JPanel();
        buttons.setLayout(new FlowLayout());
        JButton ok = new OKButton();
        buttons.add(ok);
        buttons.add(new ChancelButton());
        if (properties != null){
            buttons.add(new SaveButton());
        }
        BorderLayout bLayout = new BorderLayout();
        frame.setTitle(dialogTitle);
        frame.setLayout(bLayout);
        frame.getContentPane().add(builder.getPanel(), BorderLayout.NORTH);

        frame.getContentPane().add(buttons, BorderLayout.SOUTH);
        frame.setModal(true);
        frame.pack();
        handleDisplaySize();
        resizeFrame();
        ok.requestFocus();
        frame.setVisible(true);

    }

    private void handleDisplaySize() {
        if (cmps.size() <= 4 && !(cmps.size() > 6)) {
            frame.setSize(200, 200);
        } else if (cmps.size() <= 8) {
            frame.setSize(200, 300);
        } else {
            frame.setSize(200, 400);
        }
    }

    private void resizeFrame() {
        Dimension greatest = getGreatestDimension();
        /*
         * for (DialogComponent cmp : cmps) { Dimension d =
         * cmp.getComponent().getSize(); if (isBigger(d, greatest)) { Dimension
         * n = new Dimension(greatest.width, d.height); System.out.println("cmp
         * name: " + cmp.getComponent().getName());
         * cmp.getComponent().setSize(n); } }
         */
        frame.setSize(greatest.width * 2, frame.getSize().height);
    }

    private Dimension getGreatestDimension() {
        Dimension greatest = null;
        for (DialogComponent cmp : cmps) {
            Dimension d = cmp.getComponent().getSize();
            if (greatest == null || isBigger(greatest, d)) {
                greatest = d;
            }
        }
        return greatest;
    }

    private boolean isBigger(Dimension latest, Dimension newest) {
        return latest.width < newest.width;
    }

    private void setValuesToProject(boolean fromComponents) {
        if (fromComponents){
            for (DialogComponent cmp : cmps) {
                Property prop = new Property();
                prop.setProject(getProject());
                prop.setName(cmp.getName());
                prop.setValue(cmp.getValue());
                prop.execute();
                getProject().addReference(cmp.getComponent().getName(), prop);
            }
        } else {
            Properties values = new Properties();
            try {
                values.load(new FileInputStream(properties));
                Set propertys = values.keySet();
                validate(propertys, values);
                for (Object object : propertys) {
                    String name = object.toString();
                    Property prop = new Property();
                    prop.setProject(getProject());
                    prop.setName(name);
                    prop.setValue(values.getProperty(name));
                    prop.execute();
                    getProject().addReference(name, prop);
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(frame, "Can't load properties file: " + properties.getName()); 
            } catch (IOException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(frame, e.getMessage());
            }
        }
    }
    
    private void validate(Set propertys, Properties values){
        StringBuilder builder = new StringBuilder(100);
        builder.append("the following attributes: ");
        boolean error = Boolean.FALSE;
        for (DialogComponent cmp : cmps) {
            if (cmp.isReqiured() && isEmpty(values, cmp.getName())){
                error = Boolean.TRUE;
                builder.append(cmp.getName()).append(", ");
            }
        }
        if (error){
            builder.append(" must not be null");
            getProject().fireBuildFinished(new BuildException(builder.toString()));
        }
    }
    
    private boolean isEmpty(Properties values, String property){
        String s = values.getProperty(property);
        return s == null ? Boolean.TRUE : s.equals("");
    }

    private class OKButton extends JButton {
        public OKButton() {
            super("OK");
            this.addKeyListener(new KeyAdapter() {
                public void keyPressed(KeyEvent evt) {
                    if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
                        processOK();
                    }
                }
            });

            this.addActionListener(new ActionListener()

            {
                public void actionPerformed(ActionEvent e) {
                    processOK();
                }
            });

        }

        private void processOK() {
            try {
                for (DialogComponent cmp : cmps) {
                    if (cmp.getValue() == null || cmp.getValue().equals("")
                            && cmp.isReqiured()) {
                        getProject().fireBuildFinished(
                                new BuildException("the attribute: "
                                        + cmp.getComponent().getName()
                                        + " must not be null"));
                    }
                }
                setValuesToProject(true);
            } finally {
                frame.dispose();
            }
        }
    }

    private class SaveButton extends JButton {

        public SaveButton() {
            super("save");
            this.addActionListener(new ActionListener() {

                public void actionPerformed(ActionEvent arg0) {
                    Properties values = new Properties();
                    for (DialogComponent cmp : cmps) {
                        values.setProperty(cmp.getName(), cmp.getValue());
                    }
                    try {
                        values.store(new FileOutputStream(properties), "");
                    } catch (IOException e) {
                        e.printStackTrace();
                        JOptionPane.showMessageDialog(frame, "Can't save the values to tmpDir file");
                    }
                }

            });
        }

    }

    private class ChancelButton extends JButton {
        public ChancelButton() {
            super("Chancel");
            this.addActionListener(new ActionListener()

            {
                public void actionPerformed(ActionEvent e) {
                    frame.dispose();
                    getProject().fireBuildFinished(
                            new BuildException("Build chanceled by User"));

                }
            });
        }
    }
}
