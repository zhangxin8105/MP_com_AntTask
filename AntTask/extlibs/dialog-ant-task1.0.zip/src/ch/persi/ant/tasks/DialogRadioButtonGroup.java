package ch.persi.ant.tasks;

import java.awt.Component;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.DefaultButtonModel;
import javax.swing.JRadioButton;

import org.apache.tools.ant.Task;

public class DialogRadioButtonGroup extends Task implements DialogComponent{

	private ButtonGroup group;
	private List<DialogComponent> buttons;
	private String lableCaption;
	private boolean required = Boolean.FALSE;
	private String name;
	private RadioButtonGroupComponent groupCmp;
	
	public DialogRadioButtonGroup(){
		group = new ButtonGroup();
		buttons = new ArrayList<DialogComponent>(20);
		groupCmp = new RadioButtonGroupComponent(this);
	}
	
	public RadioButton createRadioButton(){
		RadioButton item = new RadioButton();
		buttons.add(item);
		group.add((JRadioButton)item.getComponent());
		return item;
		
	}
	
	public Component getComponent() {
		return groupCmp;
	}

	public String getLabel() {
		return lableCaption;
	}

	public void setLabel(String s) {
		lableCaption = s;
	}

	public void setRequired(boolean b) {
		required = b;
	}

	public boolean isReqiured() {
		return required;
	}

	public void setProperty(String s) {
		name = s;
		groupCmp.setName(name);
	}
	
	public String getName(){
		return name;
	}
	
	public Enumeration<AbstractButton> getRadioButtons(){
		return group.getElements();
	}

	public String getValue() {
		for(Enumeration e = getRadioButtons(); e.hasMoreElements();){
			JRadioButton button = (JRadioButton)e.nextElement();
			DefaultButtonModel model = (DefaultButtonModel)button.getModel();
			if (model.getGroup().isSelected(model) ){
				return button.getName();
			}
		}
		return "";
	}

}
