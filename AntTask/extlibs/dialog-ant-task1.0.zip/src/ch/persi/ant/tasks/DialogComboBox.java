package ch.persi.ant.tasks;

import java.awt.Component;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JComboBox;

import org.apache.tools.ant.Task;

public class DialogComboBox extends Task implements DialogComponent {
	
	private JComboBox combobox;
	private String lableCaption;
	private boolean required = Boolean.FALSE;
	private List<DialogComponent> values;
	
	public DialogComboBox(){
		combobox = new JComboBox();
		combobox.setEditable(Boolean.FALSE);
		values = new ArrayList<DialogComponent>(20);
	}
	
	public ComboBoxItem createComboBoxItem(){
		ComboBoxItem item = new ComboBoxItem(combobox);
		values.add(item);
		return item;
	}

	public Component getComponent() {
		return combobox;
	}

	public String getLabel() {
		return lableCaption;
	}
	
	public void setLabel(String s){
		lableCaption = s;
	}

	public void setRequired(boolean b) {
		required = b;
	}

	public boolean isReqiured() {
		return required;
	}

	public void setProperty(String s) {
		combobox.setName(s);
	}
	
	public void setValues(String[] values){
		for (String item : values) {
			combobox.addItem(item);
		}
	}
	
	public String getName(){
		return combobox.getName();
	}

	public String getValue() {
		return combobox.getSelectedItem().toString();
	}

	public String[] getValues() {
		int size = combobox.getItemCount();
		String[] values = new String[size];
		for (int i = 0; i < size; i++){
			values[i] = combobox.getItemAt(i).toString();
		}
		return values;
	}

}
