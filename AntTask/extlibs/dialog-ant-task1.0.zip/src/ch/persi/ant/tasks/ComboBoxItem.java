package ch.persi.ant.tasks;

import java.awt.Component;

import javax.swing.JComboBox;

public class ComboBoxItem implements DialogComponent {
	
	private JComboBox continer;
	private String itemValue;
	
	public ComboBoxItem(JComboBox container){
		this.continer = container;
	}

	public Component getComponent() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public String getName(){
		return "";
	}

	public String getLabel() {
		return "";
	}

	public boolean isReqiured() {
		return Boolean.FALSE;
	}

	public String getValue() {
		return itemValue;
	}
	
	public void setValue(String s){
		itemValue = s;
		continer.addItem(itemValue);
	}

}
