package ch.persi.ant.tasks;

import java.awt.Component;

import javax.swing.JRadioButton;

public class RadioButton implements DialogComponent {

	private JRadioButton cmp;
	private String name;
	
	public RadioButton(){
		cmp = new JRadioButton();
	}
	
	public Component getComponent() {
		return cmp;
	}
	
	public String getName(){
		return cmp.getName();
	}

	public String getLabel() {
		return cmp.getLabel();
	}

	public void setLabel(String s) {
		cmp.setLabel(s);
	}

	public boolean isReqiured() {
		//required flag has no effect on this level
		return Boolean.FALSE;
	}
    
    public void setValue(String s){
        name = s;
        cmp.setName(name);
    }

	public String getValue() {
		// this option not used on this component, only the group implements the getValue Method
		return "";
	}

}
